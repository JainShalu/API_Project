package apiEndpoints;

import static io.restassured.RestAssured.given;

import java.io.FileNotFoundException;

import apiPayload.UserPayload;
import apiUtility.ReadData;
import io.restassured.response.Response;

public class UserEndPoints {
	
	 public static Response getUserById(String id) {
		 Response response=	given()
				 .pathParam("id", id)
				 .header("Content-Type","application/json")
				 .header("Accept", "application/json")

				 .when()
				 .get(Routes.getbyID_url);
		 return response;
	 }
	
	 
	 public static Response getUser() {
		 Response response=	given()
				 .header("Content-Type","application/json")
				 .header("Accept", "application/json")

				 .when()
				 .get(Routes.get_url);
		 return response;
	 }

	  //create using static text payload
		public static Response createSimpleUser() throws FileNotFoundException{
			String fileData=ReadData.getFileData("C:\\Users\\002F2S744\\eclipse-workspace\\HandsonRest\\src\\test\\java\\apiPayload\\postData.txt");	 
			Response response=given()
					.body(fileData)
					.header("Content-Type","application/json")
					.header("Accept", "*/*")

					.when()
					.post(Routes.post_url);
			
			return response;
		}
		
		 public static Response UpdateSimpleUser(String id) throws FileNotFoundException {
			 String fileData=ReadData.getFileData("C:\\Users\\002F2S744\\eclipse-workspace\\HandsonRest\\src\\test\\java\\apiPayload\\updateData.txt");	 
				Response response=given()
						.pathParam("id", id)
						.body(fileData)
						.header("Content-Type","application/json")
						.header("Accept", "*/*")

						.when()
						.put(Routes.put_url);
				
				return response;
		 }
	
		 
	//create using  payload
		public static Response createUser(UserPayload payload) throws FileNotFoundException{
		
			Response response=given()
					.body(payload)
					
					  .header("Content-Type","application/json") 
					  .header("Accept","*/*")
					 

					.when()
					.post(Routes.post_url);
			
			return response;
		}
		
		 
		 public static void UpdateUser(String id,String payload) {
			 Response response=	given()
					 .pathParam("id", id)
					 .header("Content-Type","application/json")
					 .header("Accept", "application/json")
					 .body(payload)

					 .when()
					 .put(Routes.put_url);
		 }
		 
		 public static Response DeleteUser(String id) {
			 Response response=	given()
					 .pathParam("id", id)
					 .header("Content-Type","application/json")
					 .header("Accept", "application/json")


					 .when()
					 .delete(Routes.delete_url);
			 
			 return response;
		 }
}
