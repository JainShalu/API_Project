package apiEndpoints;

import static io.restassured.RestAssured.given;

import java.io.FileNotFoundException;

import apiUtility.ReadData;
import io.restassured.response.Response;

public class ActivitiesEndPoints {

	 public static Response getActivityById(String id) {
		 Response response=	given()
				 .pathParam("id", id)
				 .header("Content-Type","application/json")
				 .header("Accept", "application/json")

				 .when()
				 .get(Routes.getbyID_activity_url);
		 return response;
	 }
	
	 
	 public static Response getActivity() {
		 Response response=	given()
				 .header("Content-Type","application/json")
				 .header("Accept", "application/json")

				 .when()
				 .get(Routes.get_activity_url);
		 return response;
	 }
	 

		public static Response createActivity() throws FileNotFoundException{
			String fileData=ReadData.getFileData("C:\\Users\\002F2S744\\eclipse-workspace\\HandsonRest\\src\\test\\java\\apiPayload\\postActivityData.txt");	 
			Response response=given()
					.body(fileData)
					.header("Content-Type","application/json")
					.header("Accept", "*/*")

					.when()
					.post(Routes.post_activity_url);
			
			return response;
		}
		
		 public static Response UpdateActivity(String id) throws FileNotFoundException {
			 String fileData=ReadData.getFileData("C:\\Users\\002F2S744\\eclipse-workspace\\HandsonRest\\src\\test\\java\\apiPayload\\updateActivityData.txt");	 
				Response response=given()
						.pathParam("id", id)
						.body(fileData)
						.header("Content-Type","application/json")
						.header("Accept", "*/*")

						.when()
						.put(Routes.put_activity_url);
				
				return response;
		 }
		 
		 public static Response DeleteActivity(String id) {
			 Response response=	given()
					 .pathParam("id", id)
					 .header("Content-Type","application/json")
					 .header("Accept", "application/json")


					 .when()
					 .delete(Routes.delete_activity_url);
			 
			 return response;
		 }
}
