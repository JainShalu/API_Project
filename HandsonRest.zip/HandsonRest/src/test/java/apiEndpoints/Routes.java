package apiEndpoints;

public class Routes {

	public static String base_url="https://fakerestapi.azurewebsites.net";
	
	//Users Module
	public static String get_url=base_url+"/api/v1/Users";
	public static String getbyID_url=base_url+"/api/v1/Users/{id}";
	public static String post_url=base_url+"/api/v1/Users";
	public static String put_url=base_url+"/api/v1/Users/{id}";
	public static String patch_url=base_url+"/api/v1/Users/{id}";
	public static String delete_url=base_url+"/api/v1/Users/{id}";
	
	
	//Activities Module
	public static String get_activity_url=base_url+"/api/v1/Activities";
	public static String getbyID_activity_url=base_url+"/api/v1/Activities/{id}";
	public static String post_activity_url=base_url+"/api/v1/Activities";
	public static String put_activity_url=base_url+"/api/v1/Activities/{id}";
	public static String delete_activity_url=base_url+"/api/v1/Activities/{id}";
	
	
	
}
