package apiUtility;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadData {
	public static String getFileData(String filepath) throws FileNotFoundException {
		File f=new File(filepath);
		Scanner s= new Scanner(f);
		s.useDelimiter("\\Z");
		return s.next();
		
	}
}
