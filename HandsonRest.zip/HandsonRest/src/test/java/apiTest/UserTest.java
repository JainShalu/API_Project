package apiTest;


import java.io.FileNotFoundException;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import apiEndpoints.UserEndPoints;
import apiPayload.UserPayload;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class UserTest {

	Faker faker;
	UserPayload userPayload;


	@BeforeClass
	public void setupData() {
		faker=new Faker();
		userPayload=new UserPayload();
		Faker faker = new Faker();
		userPayload.setId(faker.idNumber().hashCode());
		userPayload.setUsername(faker.name().username());
		userPayload.setPassword(faker.internet().password(5, 7));	
	}


	@Test(priority=1)
	public void testGetUser() {
		Response response=UserEndPoints.getUser();
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);

	}


	@Test(priority=2)
	public void testPostUser() throws FileNotFoundException {

		Response response=UserEndPoints.createSimpleUser();
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}


	@Test(priority=3)
	public void testGetUserByID() throws FileNotFoundException {

		Response response=UserEndPoints.getUserById("10");
		response.then().log().all();
		System.out.println("Response body" +response.getBody().asString());
		System.out.println("Api headers are: "+response.getHeaders());
		System.out.println("Request response in preety format is:"+response.asPrettyString());
		JsonPath j=response.jsonPath();
		String expectedUserName=j.get("userName");
		Assert.assertEquals(expectedUserName, "User 10");
		System.out.println("Username field successfully validated");
		String expectedpassword=j.get("password");
		Assert.assertEquals(expectedpassword, "Password10");
		System.out.println("Password field successfully validated");
		Assert.assertEquals(response.getStatusCode(), 200);
		System.out.println("Status code successfully validated");
		// Validate if Response Body Contains a specific String
	    Assert.assertTrue(response.getBody().asString().contains("id"));
	    System.out.println("Validate: json body has id field");
	}

	@Test(priority=4)
	public void testUpdateUser() throws FileNotFoundException {

		Response response=UserEndPoints.UpdateSimpleUser("1");
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority=5)
	public void testDeleteUser() throws FileNotFoundException {
		Response response=UserEndPoints.DeleteUser("2");
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
}
