package apiTest;

import java.io.FileNotFoundException;

import org.testng.Assert;
import org.testng.annotations.Test;

import apiEndpoints.ActivitiesEndPoints;
import apiEndpoints.UserEndPoints;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ActivitiesTest {


	@Test(priority=1)
	public void testGetActivity() {
		Response response=ActivitiesEndPoints.getActivity();
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);

	}

	@Test(priority=2)
	public void testPostActivity() throws FileNotFoundException {

		Response response=ActivitiesEndPoints.createActivity();
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
	
	@Test(priority=3)
	public void testGetActivityByID() throws FileNotFoundException {

		Response response=ActivitiesEndPoints.getActivityById("1");
		response.then().log().all();
		System.out.println("Response body" +response.getBody().asString());
		System.out.println("Api headers are: "+response.getHeaders());
		System.out.println("Request response in preety format is:"+response.asPrettyString());
		JsonPath j=response.jsonPath();
		String expectedtitle=j.get("title");
		Assert.assertEquals(expectedtitle, "Activity 1");
		System.out.println("title field successfully validated");
		Boolean expectedStatus=j.get("completed");
		Assert.assertEquals(expectedStatus,false);
		System.out.println("Complete Status field successfully validated");
		Assert.assertEquals(response.getStatusCode(), 200);
		System.out.println("Status code successfully validated");
		// Validate if Response Body Contains a specific String
	    Assert.assertTrue(response.getBody().asString().contains("id"));
	    System.out.println("Validate: json body has id field");
	}
	
	@Test(priority=4)
	public void testUpdateActivity() throws FileNotFoundException {

		Response response=ActivitiesEndPoints.UpdateActivity("1");
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority=5)
	public void testDeleteUser() throws FileNotFoundException {
		Response response=ActivitiesEndPoints.DeleteActivity("2");
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

}
